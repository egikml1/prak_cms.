<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(alertbs_form($errors)); ?>

        <div class="row">
            <div class="col-sm-4">
                <div class="card card-rounded">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title pt-2"> 
                            <?php if(!empty($request->get('id'))): ?>
                                <i class="fas fa-edit me-1"></i>
                            <?php else: ?> 
                                <i class="fas fa-plus me-1"></i> 
                            <?php endif; ?>
                            Kategori
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if(!empty($request->get('id'))): ?>
                            <form method="post" action="<?php echo e(route('admin.update_kategori')); ?>">
                        <?php else: ?> 
                            <form method="post" action="<?php echo e(route('admin.create_kategori')); ?>">  
                        <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Nama Kategori</label>
                                <?php if(!empty($request->get('id'))): ?>
                                    <input type="text" 
                                        class="form-control mt-2 <?php $__errorArgs = ["nama_kategori"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        value="<?php echo e($edit->nama_kategori); ?>" 
                                        name="nama_kategori" id="nama_kategori" placeholder="">
                                    <?php $__errorArgs = ["nama_kategori"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="hidden" value="<?php echo e($request->get('id')); ?>" name="id">
                                <?php else: ?> 
                                    <input type="text" 
                                        class="form-control mt-2 <?php $__errorArgs = ["nama_kategori"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        value="<?php echo e(old("nama_kategori")); ?>" name="nama_kategori" 
                                        id="nama_kategori" placeholder="">
                                    <?php $__errorArgs = ["nama_kategori"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endif; ?>
                            </div>
                                <button type="submit" class="btn btn-primary mt-3 btn-md">Simpan</button>
                            <?php if(!empty($request->get('id'))): ?>
                                <a href="<?php echo e(route('admin.kategori')); ?>" class="btn btn-danger mt-3">Kembali</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="card card-rounded">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title pt-2"> <i class="fas fa-database me-1"></i> Data Kategori</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered" id="example1">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Kategori</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no =1;?>
                                    <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($no); ?></td>      
                                            <td><?php echo e($r->nama_kategori); ?></td> 
                                            <td>
                                                <a href="<?php echo e(url("admin/kategori?id=$r->id")); ?>" 
                                                    class="btn btn-success btn-sm" title="Edit">
                                                    <i class="fa fa-edit"></i>  
                                                </a>   
                                                <a href="<?php echo e(url("admin/kategori/delete/$r->id")); ?>" 
                                                    class="btn btn-danger btn-sm" 
                                                    onclick="javascript:return confirm(`Data ingin dihapus ?`);" 
                                                    title="Delete">
                                                    <i class="fa fa-times"></i> 
                                                </a>
                                            </td>
                                        </tr>
                                        <?php $no++;?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="3">
                                                Tidak Ada Data
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <br>
                        <?php echo e($kategori->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko-app-master\resources\views/contents/admin/kategori.blade.php ENDPATH**/ ?>