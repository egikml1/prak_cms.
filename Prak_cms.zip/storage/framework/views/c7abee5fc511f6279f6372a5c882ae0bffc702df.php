<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card bg-primary text-white card-rounded">
            <div class="card-body text-center pt-4">
                <h4 class="card-title">
                    <b><i class="fas fa-check me-1"></i></b> 
                    Selamat Datang Admin, <b><?php echo e(auth()->user()->name); ?></b>
                </h4>
                <a href="<?php echo e(route('home.index')); ?>" target="_blank" class="btn btn-success btn-lg mt-2">
                    <i class="fas fa-rocket me-2"></i> Lihat Website
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko-app-master\resources\views/contents/admin/home.blade.php ENDPATH**/ ?>