<div class="d-none d-lg-block">
    <div class="row">
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3 mb-3 d-none d-lg-block">
            <div class="card-product">
                <a href="<?php echo e(url('produk/'.$r->id)); ?>" class="text-produk">
                    <img src="<?php echo e(url_images('gambar', $r->gambar)); ?>" class="img-fluid w-100">
                </a>
                <div class="clearfix mb-3"></div>
                <h5 class="text-produk">Rp<?php echo e(number_format($r->harga_jual)); ?>,-</h5>
                <a href="<?php echo e(url('produk/'.$r->id)); ?>" class="text-produk"><?php echo e($r->nama_produk); ?></a>
                <div class="clearfix"></div>
            </div>  
        </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="d-lg-none">
    <div class="row">
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 mb-3 d-lg-none">
            <div class="card-product">
                <a href="<?php echo e(url('produk/'.$r->id)); ?>" class="text-produk">
                    <img src="<?php echo e(url_images('gambar', $r->gambar)); ?>" class="img-fluid w-100">
                </a>
                <div class="clearfix mb-3"></div>
                <h5 class="text-produk">Rp<?php echo e(number_format($r->harga_jual)); ?>,-</h5>
                <a href="<?php echo e(url('produk/'.$r->id)); ?>" class="text-produk"><?php echo e($r->nama_produk); ?></a>
                <div class="clearfix"></div>
            </div>  
        </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
</div><?php /**PATH C:\xampp\htdocs\toko-app-master\resources\views/components/frontend/produk_list.blade.php ENDPATH**/ ?>