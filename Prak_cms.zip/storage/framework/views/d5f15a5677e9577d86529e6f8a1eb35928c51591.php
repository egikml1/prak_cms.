<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-sm-9 mx-auto">
            <!--product -->
            <div class="product">
                <h4 class="mb-4"><b><?php echo e($title); ?></b></h4>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="<?php echo e(url_images('gambar', $edit->gambar)); ?>" class="img-fluid w-100 mb-3">
                    </div>
                    <div class="col-sm-8 detail-produk">
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>Kategori</b></div>
                            <div class="col-sm-8">
                                <a class="text-produk" href="<?php echo e(url('kategori/'.$edit->id)); ?>">
                                    <?php echo e($edit->nama_kategori); ?>

                                </a>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>Nama Produk</b></div>
                            <div class="col-sm-8"><?= $edit->nama_produk;?></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>Harga jual</b></div>
                            <div class="col-sm-8 text-success"><h4><b>Rp<?= number_format($edit->harga_jual);?>,-</b></h4></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>Deskripsi</b></div>
                            <div class="col-sm-8"><?= $edit->deskripsi;?></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b></b></div>
                            <div class="col-sm-8">
                                <a class="btn btn-instagram btn-md" 
                                    href="<?php echo e($edit->link_instagram); ?>" target="_blank" role="button">
                                    <i class="fab fa-instagram"></i> Link Instagram    
                                </a>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
.btn-instagram {
    background: linear-gradient(45deg, #833ab4, #fd1d1d, #fcb045);
    color: white;
    border: none;
}
.btn-instagram:hover {
    background: linear-gradient(45deg, #833ab4, #fd1d1d, #fcb045);
    opacity: 0.8;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko-app-master\resources\views/contents/frontend/produk.blade.php ENDPATH**/ ?>